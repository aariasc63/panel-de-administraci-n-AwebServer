<?php
header('Content-Type: text/html; charset=UTF-8');

$version = "Android / AWebServer";
$server_name = $_SERVER['SERVER_NAME'] ?? '127.0.0.1'; //ip del servidor
$server_port = $_SERVER['SERVER_PORT'] ?? '8080';  // Puerto 
$document_root = $_SERVER['DOCUMENT_ROOT'] ?? __DIR__;
$php_version = phpversion();
$server_software = $_SERVER['SERVER_SOFTWARE'] ?? 'Web Server';
$server_ip = $_SERVER['SERVER_ADDR'] ?? '127.0.0.1';

$dirs = [];
$phpFiles = [];

foreach (scandir("./") as $file) {
  if (is_dir($file) && !in_array($file, [".", "..", "css", "images"])) {
    $dirs[] = $file;
  }

  if (is_file($file) && strtolower(pathinfo($file, PATHINFO_EXTENSION)) === 'php' && $file !== 'index.php') {
    $phpFiles[] = $file;
  }
}

sort($dirs);
sort($phpFiles);
?>
<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>AWebServer Android - Panel</title>
  <link rel="icon" href="./favicon.ico">
  <meta name="description" content="Panel principal estilo AWebServer Android">
  <style>
    * {
      box-sizing: border-box;
    }

    body {
      margin: 0;
      font-family: Arial, Helvetica, sans-serif;
      background: #0f1115;
      color: #e8eef5;
    }

    .topbar {
      background: linear-gradient(135deg, #0aa06e, #0b6e8a);
      padding: 18px 16px;
      box-shadow: 0 2px 12px rgba(0, 0, 0, .35);
    }

    .topbar h1 {
      margin: 0;
      font-size: 1.4rem;
      font-weight: 700;
    }

    .topbar .sub {
      margin-top: 4px;
      font-size: .92rem;
      opacity: .92;
    }

    .container {
      width: 100%;
      max-width: 1100px;
      margin: 0 auto;
      padding: 18px;
    }

    .grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
      gap: 16px;
    }

    .card {
      background: #171b22;
      border: 1px solid #26313d;
      border-radius: 16px;
      padding: 18px;
      box-shadow: 0 4px 18px rgba(0, 0, 0, .22);
    }

    .card h2 {
      margin: 0 0 14px 0;
      font-size: 1.05rem;
      color: #56d3ff;
    }

    .info-row {
      margin-bottom: 8px;
      line-height: 1.45;
      word-break: break-word;
    }

    .label {
      color: #8fb7c8;
      font-weight: 700;
    }

    .value {
      color: #ffffff;
    }

    .status {
      display: inline-block;
      padding: 6px 10px;
      border-radius: 999px;
      background: rgba(18, 179, 113, .16);
      color: #5ef0af;
      font-weight: 700;
      font-size: .9rem;
      border: 1px solid rgba(94, 240, 175, .24);
    }

    .links {
      display: grid;
      gap: 10px;
    }

    .link-btn {
      display: block;
      text-decoration: none;
      color: #fff;
      background: linear-gradient(135deg, #1e7bf6, #1452b8);
      padding: 12px 14px;
      border-radius: 12px;
      font-weight: 700;
      text-align: center;
      transition: transform .15s ease, opacity .15s ease;
    }

    .link-btn:hover {
      transform: translateY(-1px);
      opacity: .95;
    }

    .link-btn.green {
      background: linear-gradient(135deg, #14a86e, #0c7c58);
    }

    .link-btn.orange {
      background: linear-gradient(135deg, #d58919, #a96608);
    }

    .section-title {
      margin: 24px 0 14px;
      font-size: 1.15rem;
      color: #7ce4ff;
    }

    .list-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
      gap: 12px;
    }

    .item {
      background: #171b22;
      border: 1px solid #26313d;
      border-radius: 14px;
      padding: 14px;
    }

    .item a {
      color: #d7f6ff;
      text-decoration: none;
      font-weight: 700;
    }

    .item small {
      display: block;
      margin-top: 6px;
      color: #8ba2b0;
    }

    .empty {
      color: #ff9c9c;
      background: #2a1717;
      border: 1px solid #5e2d2d;
      border-radius: 12px;
      padding: 14px;
    }

    .footer {
      text-align: center;
      color: #8ba2b0;
      padding: 24px 12px 34px;
      font-size: .92rem;
    }

    .badge {
      display: inline-block;
      padding: 4px 8px;
      font-size: .78rem;
      border-radius: 8px;
      background: #243242;
      color: #9ddcff;
      margin-left: 6px;
    }

    @media (max-width: 640px) {
      .topbar h1 {
        font-size: 1.2rem;
      }

      .container {
        padding: 14px;
      }

      .card {
        padding: 15px;
      }
    }
  </style>
</head>

<body>

  <div class="topbar">
    <div class="container" style="padding:0 18px;">
      <h1>📱 AWebServer Android <span class="badge">Panel Principal</span></h1>
      <div class="sub">Servidor web local · PHP activo · Acceso rápido a recursos</div>
    </div>
  </div>

  <div class="container">

    <div class="grid">
      <div class="card">
        <h2>Estado del servidor</h2>
        <div class="info-row">
          <span class="label">Estado:</span>
          <span class="status">En ejecución</span>
        </div>
        <div class="info-row">
          <span class="label">Servidor:</span>
          <span class="value"><?php echo htmlspecialchars($server_software, ENT_QUOTES, 'UTF-8'); ?></span>
        </div>
        <div class="info-row">
          <span class="label">PHP:</span>
          <span class="value"><?php echo htmlspecialchars($php_version, ENT_QUOTES, 'UTF-8'); ?></span>
        </div>
        <div class="info-row">
          <span class="label">Host:</span>
          <span class="value"><?php echo htmlspecialchars($server_name, ENT_QUOTES, 'UTF-8'); ?></span>
        </div>
        <div class="info-row">
          <span class="label">Puerto:</span>
          <span class="value"><?php echo htmlspecialchars($server_port, ENT_QUOTES, 'UTF-8'); ?></span>
        </div>
        <div class="info-row">
          <span class="label">IP:</span>
          <span class="value"><?php echo htmlspecialchars($server_ip, ENT_QUOTES, 'UTF-8'); ?></span>
        </div>
      </div>

      <div class="card">
        <h2>Información del entorno</h2>
        <div class="info-row">
          <span class="label">Plataforma:</span>
          <span class="value"><?php echo htmlspecialchars($version, ENT_QUOTES, 'UTF-8'); ?></span>
        </div>
        <div class="info-row">
          <span class="label">Directorio raíz:</span>
          <span class="value"><?php echo htmlspecialchars($document_root, ENT_QUOTES, 'UTF-8'); ?></span>
        </div>
        <div class="info-row">
          <span class="label">Hora del sistema:</span>
          <span class="value"><?php echo date('Y-m-d H:i:s'); ?></span>
        </div>
      </div>

      <div class="card">
        <h2>Accesos rápidos</h2>
        <div class="links">
          <a class="link-btn green" href="server_info.php" target="_blank">📊 Server Info</a>
          <a class="link-btn" href="info.php" target="_blank">⚙️ PHP Info</a>
          <a class="link-btn orange" href="mysqladmin" target="_blank">🗄️ phpMyAdmin</a>
          <a class="link-btn" href="ftp_admin.php" target="_blank">⚙️ FTP server</a>
        </div>
      </div>
    </div>

    <h2 class="section-title">📁 Subdirectorios disponibles</h2>

    <?php if (count($dirs) > 0): ?>
      <div class="list-grid">
        <?php foreach ($dirs as $index => $dir): ?>
          <div class="item">
            <a href="<?php echo rawurlencode($dir); ?>/" target="_blank">
              <?php echo ($index + 1) . '. ' . htmlspecialchars($dir, ENT_QUOTES, 'UTF-8'); ?>
            </a>
            <small>Abrir carpeta en nueva pestaña</small>
          </div>
        <?php endforeach; ?>
      </div>
    <?php else: ?>
      <div class="empty">No se encontraron subdirectorios en esta ruta.</div>
    <?php endif; ?>


  </div>

  <div class="footer">
    Copyright Aicasoft / AWebServer · PHP
    <?php echo htmlspecialchars($php_version, ENT_QUOTES, 'UTF-8'); ?>
  </div>

</body>

</html>